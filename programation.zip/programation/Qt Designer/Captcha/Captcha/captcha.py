from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from random import randint

'''Le module ChBin permet de créer une chaine aléatoire de 26 lettres chiffres ("0" et "1")
   et de l'afficher dans le label res'''
def ChBin () :
    cap=""
    for i in range(26):  
        x=randint(0,1)
        cap=cap+ str(x)
    fen.res.setText(cap)
def code(cap):
    res=""
    k=0
    for i in range(len(cap)):
        if cap[i]=="1" :
            res=res+chr(97+i)
    k=100+voyelle(res)
    res=res+chr(k)
    return res
def voyelle(res):
    v="oeauy"
    n=0
    for i in range(len(res)):
        if(v.find(res[i])!=-1):
            n=n+1
    return n
def remplir():
    cap=fen.res.text()
    if(cap==""):
        QMessageBox.critical(fen,"Attention","Cliquer sur le boutton Générer")
    else:
        f=open("captcha.txt","a")
        f.write(cap+"\n")
        f.write(code(cap)+"\n")
        f.close()
        QMessageBox.information(fen,"Information","Ajout Avec Succées")
def afficher(): 
    try:
        f=open("captcha.txt","r")
        ff=False
        i=0
        fen.tw.setRowCount(0)
        res=f.readline()
        while not res=="":
                fen.tw.insertRow(i)
                fen.tw.setItem(i,0,QTableWidgetItem(res))
                res=f.readline()
                fen.tw.setItem(i,1,QTableWidgetItem(res))
                res=f.readline()
                i=i+1
        f.close()
    except:
        QMessageBox.warning(fen,"Attention","Cliquer sur le boutton Ajouter pour remplir le fichier")
        
    
    
            

    
# Exploitation de l'interface graphique
app = QApplication([])                   
fen = loadUi("Interface_captcha.ui") 
fen.show()                            
fen.Bg.clicked.connect(ChBin) 
fen.Baj.clicked.connect(remplir) 
fen.aff.clicked.connect(afficher)                                         
app.exec_()                             