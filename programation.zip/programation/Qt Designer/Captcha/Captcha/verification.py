from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox
from random import randint
def codeAlea():
    f=open("captcha.txt","r")
    ch=f.readline()
    n=0
    while not(ch==""):
        ch=f.readline()
        n=n+1
    f.close()
    print(n)
    indcap=randint(0,n)
    if(indcap%2!=0):
        indcap=indcap+1
    f=open("captcha.txt","r")
    for i in range(indcap):
        cp=f.readline()
    f.close()
    print(cp)
    cp=cp[0:len(cp)-1]
    fen.captcha.setText(cp)
def verif():
    cp=fen.captcha.text()
    le=fen.le.text()
    print(fen.ckb.isChecked())
    print(cp!=le)
    if(fen.ckb.isChecked()==False or cp!=le):
        fen.labAff.setText("Vous devez cocher la case et réécrir le code!!")
    else:
        fen.labAff.setText("Félicitation! Bienvenue dans notre site!!")
    
 
# Explotation de l'interface graphique
app = QApplication([])                   
fen = loadUi("Interface_verif.ui") 
fen.show()                                    
fen.Bverif.clicked.connect(verif)
fen.Bcode.clicked.connect(codeAlea)                                  
app.exec_()                             