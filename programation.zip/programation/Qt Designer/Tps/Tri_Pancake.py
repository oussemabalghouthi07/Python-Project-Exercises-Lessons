from numpy import*
def saisir():
    global n
    n=int(input("donner un taille pour le tableau T:"))
    while not 4<=n<=10 :
        n=int(input("donner un taille pur le tableau T:"))
def remplire(T,n):
    for i in range(n):
        T[i]=int(input("T["+str(i)+"]:"))
def Tri_pancake(T,n):
    for i in range(n-1,1,-1):
        p=pos_Max(T,i)
        if(i!=p):
            rotation(T,p)
            rotation(T,i)
def pos_Max(T,x):
    max=T[0]
    ind=0
    for i in range(1,x):
        if max<T[i]:
            max=T[i]
            ind=i
    print(ind)
    return ind
def rotation(T,x):
    s=0
    b=0
    for i in range((x//2)+1):
        s=T[i]
        b=T[x-i]
        T[i]=b
        T[x-i]=s
    print(T)
        
   
   
   
   
   
   
   
   
   
    

saisir()
T=array([int]*n)
remplire(T,n)
Tri_pancake(T,n)
