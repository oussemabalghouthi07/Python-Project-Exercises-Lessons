def determination():
    global nbl,nbc
    v=f1.readline()
    nbl=int(v[0])
    nbc=int(v[2])
def insertion(m,nbl,nbc):
    for i in range(nbl):
        for j in range(nbc):
            m[i,j]=-1
    print(m)
def remplire(m,nbl,nbc):
    v=f1.readline()
    print(v)
    while(v!=""):
         v=v[0:len(v)-1]
         for k in range(len(v)//4):
             bloc=v[0:4]
             x=int(bloc[0])
             y=int(bloc[1])
             m[x,y]=int(bloc[2:4])
             v=v[4:len(v)]
         v=f1.readline()
    print(m)
         
        
        
    
    
def Tri_pancake(T,n):
    for i in range(n-1,1,-1):
        p=pos_Max(T,i)
        if(i!=p):
            rotation(T,p)
            rotation(T,i)
def pos_Max(T,x):
    max=T[0]
    ind=0
    for i in range(1,x+1):
        if max<T[i]:
            max=T[i]
            ind=i
    return ind
def rotation(T,x):
    for i in range((x+1)//2):
        v=T[i]
        T[i]=T[x-i]
        T[x-i]=v
    
def transfer(T,m,nbl,nbc):
    for i in range (nbl):
        for j in range(nbc):
            T[j]=m[i,j]
      
        Tri_pancake(T,nbc)
        print(T)
        for k in range(nbc):
            m[i,k]=T[k]
    print(m)
def creation(m,nbl,nbc):
    for j in range(nbc):
        sb=""
        for i in range(nbl):
            if m[i,j]!=-1:
                sb=sb+chr((m[i,j]))
        f2.write(sb+"\n")
                
            

from numpy import array
f1=open("Message_Crypt.txt","r")
determination()
f1.close()
m= array([[int]*nbc]*nbl)
insertion(m,nbl,nbc)
f1=open("Message_Crypt.txt","r")
remplire(m,nbl,nbc)
f1.close()
T=array([int]*nbl)
transfer(T,m,nbl,nbc)
Tri_pancake(T,nbc)
f2=open("Message_Clair.txt","w")
creation(m,nbl,nbc)
f2.close()

