from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidgetItem
from pickle import dump, load
def Crypter():
    ch=win.te1.toPlainText()
    if ch=="":
        QMessageBox.critical(win,"Erreur saisie","vous devez saisir un text!")
    elif verif(ch)==False:
        QMessageBox.critical(win,"Erreur saisie","verifier votre text !")
    else:
        v=cryptage(ch)
        win.te2.setText(v)
        if win.cc.isChecked()==True:
            f1=open("ph_crypt.txt","a")
            f1.write(v+"\n")
            f1.close()
            QMessageBox.information(win,"Ajout","Ajout dans le fichier avec succés")
            
       
def cryptage(ch):
    chn=""
    l=1
    for i in range(len(ch)):
        s=0
        if "A"<=ch[i].upper()<="Z":
            for j in range(len(ch)):
                if ch[i].upper()==ch[j].upper():
                    s=s+1
            if ord(ch[i].upper())-s>=65:
                chn=chn+chr(ord(ch[i])-s)
            else:
                chn=chn+chr(ord(ch[i])-s+26)
        elif ch[i]==" ":
            chn=chn+"*"
        else:
            chn=chn+str(l)
            l=l+1
    return chn
def Afficher():
    win.lw.clear()
    try:
        f1=open("ph_crypt.txt","r")
        k=f1.read()
        win.lw.addItem(k)
        win.te2.setText(ch)
        f.close()
    except:
        QMessageBox.critical(win,"Erreur","le fichier est inexistant")
def verif(ch):
    test=True
    i=0
    while (i<len(ch) and test):
        if "a"<=ch[i]<="z" or "A"<=ch[i]<="Z" or ch[i]==" " or "0"<=ch[i]<="9":
            i=i+1
        else:
            test=False
    return test

def effacer():
    win.lw.clear()
    win.te1.clear()
    win.te2.clear()
#Exploitation de l'interface graphique
app=QApplication([])
win=loadUi("Inter_Crypt.ui")
win.show()
win.btc.clicked.connect(Crypter)
win.bta.clicked.connect(Afficher)
win.bt2.clicked.connect(effacer)
app.exec_()
