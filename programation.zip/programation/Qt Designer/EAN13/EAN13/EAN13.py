from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidgetItem
from pickle import dump, load
"""Module qui permet de vérifier si une chaine ch est composée que par des
lettres ou des espaces """
def Verif(ch):
    i=0
    while (i<len(ch)) and ((ch[i]==" ") or ("A"<=ch[i]<="Z") or ("a"<=ch[i]<="z")):
        i=i+1
    return i==len(ch)
def num(x):
    i=0
    while "0"<x<"9" and i<len(x):
        i=i+1
    return i==len(x)
def Ajout():
    cd=win.cd.text()
    lib=win.lib.text()
    qte=win.qte.text()
    if(len(cd)!=13 or num(cd)==False):
        QMessageBox.critical(win,"Erreur code","Le code doit etre de 13 chiffre!")
        win.cd.clear()
        win.lib.clear()
        win.qte.clear()
    elif(Verif(lib)==False):
        QMessageBox.critical(win,"Erreur libellé","Le libellé doit etre former par des lettres alphabétiques et/ou des espaces !")
        win.cd.clear()
        win.lib.clear()
        win.qte.clear()
    elif(qte=="" or int(qte)<0):
        QMessageBox.critical(win,"Erreur quantité","La quantité doit etre positive!")
        win.cd.clear()
        win.lib.clear()
        win.qte.clear()
    elif(win.type.currentText()==""):
        QMessageBox.critical(win,"Erreur type","Vous devez choisir un type!")
        win.cd.clear()
        win.lib.clear()
        win.qte.clear()
    elif(win.origi.isChecked==False and win.origl.isChecked==False):
        QMessageBox.critical(win,"Erreur nature","Vous devez cocher la nature!")
        win.cd.clear()
        win.lib.clear()
        win.qte.clear()
    else:
        e=dict(cd=int,lib=str,qte=int,typ=str,orig=str)
        f1=open("produit.dat","ab")
        e["cd"]=int(cd)
        e["lib"]=lib
        e["qte"]=int(qte)
        e["typ"]=win.type.currentText()
        if win.origi.isChecked:
            e["orig"]="Importé"
        else:
            e["orig"]="local"
        dump(e,f1)
        f1.close()
        QMessageBox.information(win,"Ajout","Produit ajouter avec succées")
def Afficher():
    f1=open("produit.dat","rb")
    ff=False
    i=0
    win.tw.setRowCount(0)
    while not ff:
        try:
            e=load(f1)
            win.tw.insertRow(i)
            win.tw.setItem(i,0,QTableWidgetItem(str(e["cd"])))
            win.tw.setItem(i,1,QTableWidgetItem(str(e["lib"])))
            win.tw.setItem(i,2,QTableWidgetItem(str(e["qte"])))
            win.tw.setItem(i,3,QTableWidgetItem(str(e["typ"])))
            win.tw.setItem(i,4,QTableWidgetItem(str(e["orig"])))
            i=i+1
        except:
            ff=True
    f1.close()
def immutation():
    win.lw.clear()
    f1=open("produit.dat","rb")
    f2=open("immutation.txt","w")
    ff=False
    while not ff:
        try:
            e=load(f1)
            cd=str(e["cd"])
            cc=int(cd[len(cd)-1])
            
            print(cd)
            s=0
            for i in range (0,len(cd)-1):
                if i%2!=0 and i!=0:
                    s=s+int(cd[i])*3
                else:
                    s=s+int(cd[i])
            r=s%10
            p=10-r
            print(s)
            print(p)
            print(cc)
            if p!=cc:
                f2.write(cd+" "+e["lib"]+"\n")
        except:
            ff=True
    f2.close()
    f1.close()
    f2=open("immutation.txt","r")
    ch=f2.read()
    win.lw.addItem(ch)
    f2.close()
    
            
#programme principal
app=QApplication([])
win=loadUi("inter_EAN13.ui")
win.show()
win.btap.clicked.connect(Ajout)
win.btas.clicked.connect(Afficher)
win.btapi.clicked.connect(immutation)

app.exec_()
