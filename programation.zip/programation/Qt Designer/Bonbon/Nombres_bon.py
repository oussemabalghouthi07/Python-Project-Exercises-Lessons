from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidget,QTableWidgetItem
from random import randint
from pickle import*
def nombre_alea(b,ta):
    ch=str(randint(1,9))
    for i in range(1,ta):
        c=randint(0,b-1)
        if(c<10):
            ch=ch+str(c)
        else:
            ch=ch+chr(c+55)
    return ch
def premier(x):
    test=True
    i=2
    while (test and i<(x//2)):
        if x%i!=0:
            i=i+1
        else:
            test=False
    return test
def decomposition(x):
    i=2
    res=""
    while not (x==1):
        if(x%i==0):
            res=res+str(i)+"*"
            x=x//i
        else:
            i=i+1
        
    res=res[0:len(res)-1]
    return res
def bonbon(nb,decomp):
    ch=str(nb)
    s=0
    for i in range(len(decomp)):
        if(decomp[i]=="*"):
            s=s+1
    if (len(ch)==(s+1)):
        return True
    else:
        return False
def convertion(x,b):
    s=0
    p=1
    for i in range(len(x)-1,-1,-1):
        if("A"<=x[i]<="F"):
            s=s+(ord(x[i])-55)*p
        else:
            s=s+(ord(x[i])-48)*p
        p=p*b
    return s
def remplir():
    chn=win.len.text()
    chb=win.leb.text()
    if(chn=="" or chb==""):
        QMessageBox.critical(win,"Erreur","Vous devez saisir des valeurs")
    elif(int(chb)>16 or int(chb)<2 or int(chn)<5 or int(chn)>20):
        QMessageBox.critical(win,"Erreur","valeurs erronées")
    else:
        f=open("nombres.txt","w")
        
        n=int(chn)
        b=int(chb)
        
        for i in range(n):
            ta=randint(2,4)
            nba=nombre_alea(b,ta)

            f.write(nba+"\n")
        f.close()
        e=dict(A=str,Dec=int,Fact=str)
        res=""
        f=open("nombres.txt","r")
        f2=open("resultat.dat","wb")
        for i in range(n):
            nba=f.readline()
            nba=nba[0:len(nba)-1]
            dci=convertion(nba,b)
            decomp=decomposition(dci)
            e["A"]=nba
            e["Dec"]=dci
            e["Fact"]=decomp

            dump(e,f2)
        f2.close()
        f.close()
def Afficher1():
    win.lw.clear()
    win.tw.clear()
    f=open("nombres.txt","r")
    ph=f.read()
    win.lw.addItem(ph)
    f.close()
    f2=open("resultat.dat","rb")
    ff=False
    i=0
    win.tw.setRowCount(0)
    while not ff:
        try:
            e=load(f2)
            win.tw.insertRow(i)
            
            win.tw.setItem(i,0,QTableWidgetItem(str(e["A"])))
            win.tw.setItem(i,1,QTableWidgetItem(str(e["Dec"])))
            win.tw.setItem(i,2,QTableWidgetItem(str(e["Fact"])))
            i=i+1
        except:
            ff=True
    f2.close()
def Afficher2():
    win.lw.clear()
    f=open("resultat.dat","rb")
    ff=False
    i=0
    win.lw.addItem("Les nombres bonbons sont:")
    while not ff:
        try:
            e=load(f)
            print(e)
            if( bonbon(e["Dec"],e["Fact"])==True):
                win.lw.addItem(str(e["Dec"]))
        except:
            ff=True
    f.close() 
            
        
        






app = QApplication([])
win = loadUi ("Inter_Bonbons.ui")
win.show()
win.btr.clicked.connect (remplir)
win.bta.clicked.connect (Afficher1)
win.btb.clicked.connect (Afficher2)
app.exec_()