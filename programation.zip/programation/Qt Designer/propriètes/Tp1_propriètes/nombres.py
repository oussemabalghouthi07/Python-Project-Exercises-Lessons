from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidgetItem
from pickle import dump, load
def Ajouter():
    chn=win.le.text()
    if chn=="":
        QMessageBox.critical(win,"Erreur saisie","vous devez saisir un nombre!")
    elif not(chn.isdecimal()):
        QMessageBox.critical(win,"Erreur saisie","le nombre doit etre positif!")
    else:
        f1=open("Nomres.txt","a")
        f1.write(chn+"\n")
        f1.close()
        e=dict(n=int,sd=int,prop=str)
        f2=open("proprietes.dat","ab")
        e["n"]=int(chn)
        
        e["sd"]=diviseur(e["n"])
        print("-")
        if int(chn)<diviseur(e["n"]):
            e["prop"]="Déficient"
        elif int(chn)>diviseur(e["n"]):
            e["prop"]="Abondant"
        else:
            e["prop"]="Parfait"
        dump(e,f2)
        QMessageBox.information(win,"Ajout","Ajout de l'entier avec succés")
        f2.close()
def diviseur(x):
    s=0
    for i in range(1,(x//2)+1):
        if x%i==0:
            s=s+i
    print(s)
    return s
def Afficher1():
    win.lw.clear()
    try:
        f1=open("Nomres.txt","r")
        ch=f1.read()
        win.lw.addItem(ch)
        f1.close()
    except:
        QMessageBox.critical(win,"Erreur","le fichier nombre.txt est inexistant")
def Afficher2():
    i=0
    f2=open("proprietes.dat","rb")
    win.tw.setRowCount(0)
    ff=False
    while not (ff):
        try:
            e=load(f2)
            win.tw.insertRow(i)
            
            win.tw.setItem(i,0,QTableWidgetItem(str(e["n"])))
            print(str(e["n"]))
            win.tw.setItem(i,1,QTableWidgetItem(str(e["sd"])))
            print(str(e["sd"]))
            win.tw.setItem(i,2,QTableWidgetItem(str(e["prop"])))
            print(str(e["prop"]))
            i=i+1
        except:
            ff=True
        
    
        
        
        

                 
#Exploitation de l'interface qraphique
app=QApplication([])
win=loadUi("Inter_Nombres.ui")
win.show()
win.bta.clicked.connect(Ajouter)
win.btan.clicked.connect(Afficher1)
win.btap.clicked.connect(Afficher2)
app.exec_()
