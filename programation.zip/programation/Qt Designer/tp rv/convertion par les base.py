from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidget,QTableWidgetItem
from pickle import*
def afficher():
    ch=w.le.text()
    if(ch==""):
        QMessageBox.critical(w,"Erreur 1","veuille un nombre decimal!")
    elif not(ch.isdecimal()):
         QMessageBox.critical(w,"Erreur 2","Nombre invalide!")
    else:
        w.lw.clear()
        f=open("base.txt","a")
        f.write(ch+"\n")
        f.close()
        e=dict(n=int,bs=str,nf=str)
        e["n"]=int(ch)
        if w.cb.currentText()=="2":
            e["bs"]="2"
            b=2
        elif w.cb.currentText()=="16":
            e["bs"]="16"
            b=16
        else:
            e["bs"]="8"
            b=8
        con=convertir(int(ch),b)
        e["nf"]=con
        f2=open("nombreconv.dat","ab")
        dump(e,f2)
        f2.close()
        f=open("base.txt","r")
        ch=f.read()
        w.lw.addItem(ch)
        f.close()
        QMessageBox.information(w,"validation","le nombre enregistre et afficher avec succes!")
        
            
def convertir(n,b):
    ch=""
    while not(n==0):
        r=n%b
        if r<10:
            ch=str(r)+ch
        else:
            ch=chr(r+55)+ch
        n=n//b
    return ch
def afficher2():
    f2=open("nombreconv.dat","rb")
    ff=False
    i=0
    w.tw.setRowCount(0)
    while not(ff):
        try:
            e=load(f2)
            w.tw.insertRow(i)
            w.tw.setItem(i,0,QTableWidgetItem(str(e["n"])))
            w.tw.setItem(i,1,QTableWidgetItem(str(e["bs"])))
            w.tw.setItem(i,2,QTableWidgetItem(str(e["nf"])))
            i=i+1
        except:
            ff=True
    f2.close()
            
            
app = QApplication([])
w = loadUi ("Inter_1.ui")
w.show()
w.bt1.clicked.connect (afficher)
w.bt2.clicked.connect (afficher2)
app.exec_()