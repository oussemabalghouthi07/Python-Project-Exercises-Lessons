from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidget,QTableWidgetItem
from pickle import*
def premier(x):
    test=True
    i=2
    while (test and i<(x//2)):
        if x%i!=0:
            i=i+1
        else:
            test=False
    return test
def valide(ch):
    ch1=ch[0:3]
    ch2=ch[3:8]
    ch3=ch[8:13]
    if(premier(int(ch1))==False or int(ch3)%int(ch1)!=0 or verif(ch2)==False):
        return False
    else:
        return True
def convertion(n,b):
    ch=""
    while not(n==0):
        r=n%b
        if r<10:
            ch=str(r)+ch
        else:
            ch=chr(r+55)+ch
        n=n//b
    return ch
def verif(ch):
    cv=convertion(int(ch),2)
    print(cv)
    s=0
    for i in range(len(cv)):
        if(cv[i]=="0"):
            s=s+1
    if s>8:
        return True
    else:
        return False
def ajouter():
    nt=w.le1.text()
    cr=w.le2.text()
    if(nt=="" and cr==""):
        QMessageBox.critical(w,"Erreur","Saisir les donnéees")
    elif(nt.isdecimal()==False or len(nt)!=8):
        QMessageBox.critical(w,"Erreur","Vérifier le numéro de tél")
    elif( cr.isdecimal()==False or len(cr)!=13 or cr=="" or valide(cr)==False ):
        QMessageBox.critical(w,"Erreur ","Verifier le code de recharge")
    else:
        e=dict(Ntel=str,code=str,opr=str,tp=str)
        f=open("Clients.dat","ab")
        e["Ntel"]=nt
        e["code"]=cr
        if(w.rd1.isChecked()==True):
            e["opr"]="TT"
        elif(w.rd2.isChecked()==True):
            e["opr"]="Ooredoo"
        else:
            e["opr"]="Orange"
        if(w.chk.isChecked()==True):
            e["tp"]="pres payée"
        else:
            e["tp"]="facture"
        dump(e,f)
        f.close()
def codeutil():
    f=open("code.txt","r")
    ph=f.read()
    w.lw.addItem(ph)
    f.close()
def affclient():
    f=open("Clients.dat","rb")
    ff=False
    i=0
    w.tw.setRowCount(0)
    while not ff:
        try:
            e=load(f)
            w.tw.insertRow(i)
            w.tw.setItem(i,0,QTableWidgetItem(e["Ntel"]))
            w.tw.setItem(i,1,QTableWidgetItem(e["code"]))
            w.tw.setItem(i,2,QTableWidgetItem(e["opr"]))
            w.tw.setItem(i,3,QTableWidgetItem(e["tp"]))
            i=i+1
        except:
            ff=True
    f.close()
def affrech():
    f1=open("Clients.dat","rb")
    ff=False
    while not ff:
        try:
            e=load(f1)
            res=""
            if(existe(e["code"])==True ):
                res=e["Ntel"]+"-"+e["code"]+"-"+"code de recharge déja utiliser"
            else:
                res=e["Ntel"]+"-"+e["code"]+"-"+"operation de recharge effectuer"
            w.lw2.addItem(res)
        except:
            ff=True
    f1.close()
def existe(ch):
    f2=open("code.txt","r")
    chh=f2.readline()
    chh=chh[0:len(chh)-1]
    test=False
    while chh!="" and test==False:
        if(chh==ch):
            test=True
        chh=f2.readline()
        chh=chh[0:len(chh)-1]
    f2.close()
    return test
        

        



app = QApplication([])
w = loadUi ("Interface.ui")
w.show()
w.bt1.clicked.connect (ajouter)
w.bt2.clicked.connect (affclient)
w.bt3.clicked.connect (codeutil)
w.bt4.clicked.connect (affrech)
app.exec_()