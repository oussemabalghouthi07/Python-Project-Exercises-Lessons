from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidget,QTableWidgetItem
from pickle import*
def air_rectangle(n):
    a=0
    b=3
    h=(b-a)/n
    x=a
    s=0
    for i in range (0,n):
        s=s+h*f(x)
        x=x+h
    return s
def f(x):
    return x*x
def air_trapez(n):
    a=0
    b=3
    h=(b-a)/n
    x=a
    s=0
    for i in range (0,n):
        s=s+h*(f(x)+f(x+h))/2
        x=x+h
    return s
def calculer():
    eps=w.le.text()
    p=eps.find('.')
    if(p==-1 or eps[0:p].isdecimal()==False or eps[p+1:].isdecimal()==False or eps=="" or float(eps)<0.001 or float(eps)>0.1):
        QMessageBox.critical(w,"Erreur","Saisir un réel entre 0.001 et 0.1!")
    else:
        w.lw.clear()
        e=dict(N=int,ar=float,at=float)
        f=open("calcul.dat","wb")
        n=1
        s=0
        sp=0
        s1=0
        sp1=0
        while not(abs(s-9)<=float(eps)or abs(s1-9)<=float(eps)):
            sp=s
            sp1=s1
            s=air_rectangle(n)
            s1=air_trapez(n)
            print("rct:"+str(s))
            print("trp:"+str(s1))
            print(n)
            e["N"]=n
            e["ar"]=s
            e["at"]=s1
            n=n+1
            dump(e,f)
        f.close()
        v=0
        f=open("calcul.dat","rb")
        ff=False
        i=0
        w.tw.setRowCount(0)
        while not ff:
            try:
                e=load(f)
    
                w.tw.insertRow(i)
                w.tw.setItem(i,0,QTableWidgetItem(str(e["N"])))
                w.tw.setItem(i,1,QTableWidgetItem(str(e["ar"])))
                w.tw.setItem(i,2,QTableWidgetItem(str(e["at"])))
                i=i+1
                v=e["N"]
            except:
                ff=True
        f.close()
        print(v)
        f=open("calcul.dat","rb")
        e=load(f)
        while not e["N"]==v:
            e=load(f)
            at=e["at"]
            ar=e["ar"]
        if at>ar :
           w.lw.addItem("Méthode plus proche=méthode de trapézes"+"\n"+"Valeur approchée="+str(at)+"\n"+"nombre de subdivision="+str(v))
        elif(ar>at):
           w.lw.addItem("Méthode plus proche=méthode de Rectangle"+"\n"+"Valeur approchée="+str(ar)+"\n"+"nombre de subdivision="+str(v))     
        else:
            w.lw.addItem("Méthode plus proche=méthode de trapézes et de rectangle"+"\n"+"Valeur approchée="+str(at)+"\n"+"nombre de subdivision="+str(v))


app = QApplication([])
w = loadUi ("inter_calc_air.ui")
w.show()
w.bc.clicked.connect (calculer)
app.exec_()