from PyQt5.QtWidgets import *
from PyQt5.uic import *
from numpy import array
def pgcd(a,b):
    if(b==0):
        return a
    else:
        return pgcd(b,a%b)
def chiffrer(ch,c1,c2):
    ch1=transposition(ch,c1)
    ch2=transposition(ch1,c2)
    return ch2
def transposition(ch,x):
    nc=len(x)
    nl=len(ch)//nc
    if(len(ch)%nc==0):
        nl=nl+1
    else:
        nl=nl+2
    m=array([[str()]*nc]*(nl))
    for j in range(nc):
        m[0,j]=x[j]
    i=1
    j=0
    for k in range(len(ch)):
        m[i,j]=ch[k]
        j=j+1
        if j==nc:
            j=0
            i=i+1
    trier(m,nl,nc)
    res=""
    for j in range(nc):
        for i in range(1,nl):
            res=res+m[i,j]
    return res
def trier(m,nl,nc):
    ok = False
    while not ok:
        permut = False
        for j in range(nc-1):
            if m[0,j] > m[0,j+1]:
                for i in range(nl):
                    v = m[i,j]
                    m[i,j] = m[i,j+1]
                    m[i,j+1] = v
                permut = True
        ok = (permut == False)
def crypter():
    c1=w.c1.text()
    c2=w.c2.text()
    if(len(c1)<2 or len(c1)>8 or len(c2)<2 or len (c2)>8):
        QMessageBox.critical(w,'Erreur',"chaque clé doit contenir entre 2 et 8 chiffres")
    elif(pgcd(int(c1),int(c2))!=1):
        QMessageBox.critical(w,'Erreur',"Les longueurs des deux clés doivent etre deux entiers premiers entre eux")
    else:
        f=open("source.txt","r")
        f2=open("resultat.txt","w")
        nch=f.readline()
        while  nch!="":
                nch=nch[0:len(nch)-1]
                ch=chiffrer(nch,c1,c2)
                f2.write(str(ch)+"\n")
                nch=f.readline()
        QMessageBox.information(w,"succés","Le fichier a été chiffré avec succés")
        f.close()
        f2.close()
def afficher():
    if(w.fs.isChecked()==True):
        w.lw.clear()
        f1=open("source.txt","r")
        ph=f1.read()
        w.lw.addItem(ph)
        f1.close()
    elif(w.fc.isChecked()==True):
        w.lw.clear()
        f2=open("resultat.txt","r")
        ph=f2.read()
        w.lw.addItem(ph)
        f2.close()
    else:
        QMessageBox.critical(w,"Erreur","Veuillez choisir le fichier a afficher!!")
        
        
        

#--------Programme principal-------    
app=QApplication([])
w=loadUi("Interface_Chiffrement.ui")
w.show()
w.btChiffrer.clicked.connect(crypter)
w.aff.clicked.connect(afficher)
app.exec_()

