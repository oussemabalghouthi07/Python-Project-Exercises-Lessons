from numpy import*
ch="aaaaaaaaaaaaaaaaa"
x="6325471"
nb1=len(x)
m=array([[str()]*nb1]*50)
for j in range(nb1):
    m[0,j]=x[j]
i=1
k=0
while not(k==len(ch)):
    for j in range(nb1):
        m[i,j]=ch[k]
        k=k+1
        if(ch[k]==""):
            m[i,j]=" "
    i=i+1
print(m)