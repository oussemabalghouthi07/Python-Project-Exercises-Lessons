from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from pickle import dump,load
from numpy import array

def verifid(id):
    '''permet de contrôler la validité de l'identifiant id saisi. L’identifiant doit commencer par 2 lettres
suivies de 6 chiffres'''
    test=False
    alpha=id[0:2]
    num=id[2:8]
    if(id!="" and len(id)==8 and "A"<=alpha[0]<="Z" and "A"<=alpha[1]<="Z" and num.isdecimal()==True  ):
        test=True
    else:
        test=False
    return test
   
   
def exist(id):
    '''ce module vérifie l’existence de l'identifiant id d'un élève dans le fichier "Reponses.dat"'''
    test=True
    f=open("Reponses.dat","rb")
    ff=False
    while not ff:
        try:
            e=load(f)

            if(e["id"]==id):
                test=False
        except:
            ff=True
    f.close()
    return test
        
                
   
def remplirQuiz (n,Tquiz):
    '''ce module permet de remplir le tableau Tquiz par les n enregistrements du fichier "Quiz.dat"'''
    f=open("Quiz.dat","rb")
    for i in range(n):
        Tquiz[i]=load(f)
    f.close()
    
    
def afficherQuestion(k,Tquiz):
    ''' ce module permet d’afficher à partir du tableau Tquiz, les données relatives à la question numéro
num dans les champs adéquats'''
    fen.labNum.setText(str(k))
    fen.labQues.setText(str(Tquiz[k]["ques"]))
    fen.labP1.setText(str(Tquiz[k]["p1"]))
    fen.labP2.setText(str(Tquiz[k]["p2"]))

   
    
def test():
    '''ce module permet de vérifier la validité de l’identifiant puis d’afficher les données relatives
à la première question, et ce dans le cas où l’élève n’a pas encore participé au quiz'''
    
    id = fen.txtid.text()
    if not(verifid(id.upper())) :
        QMessageBox.critical(fen,'Erreur',"l'identifiant doit commencé par 2 lettres suivies de 6 chiffres!")
    elif exist(id)==False:
        QMessageBox.critical(fen,'Erreur','Vous avez déjà participé au quiz!')
    else:
        remplirQuiz(n,Tquiz)
        afficherQuestion(numQ,Tquiz) # variable numQ dèjà initialisée dans le programme principal à 0
def validation():
    global nb,rep
    if(nb==(n)):
        QMessageBox.information(fen,"Validation","Votre participant est ajouter avec succés")
        f=open("Reponses.dat","ab")
        dump(Trep,f)
        f.close()
        fen.labRes.setText(str(rep))
    else:
        
        id=fen.txtid.text()
        ques=fen.labQues.text()
        if(fen.btrP1.isChecked()==True):
            nump=1
        else:
            nump=2
        print(id)
        Trep[nb]["id"]=id
        Trep[nb]["ques"]=ques
        Trep[nb]["nump"]=nump
        if(Trep[nb]["nump"]==Tquiz[nb]["rep"]):
            rep=rep+1
        print(nb)
        afficherQuestion(nb,Tquiz)
        nb=nb+1

    
    


        


    
#Le programme principal à compléter
rep=0
nb=0
n = 5 # le nombre de questions du Quiz
Tquiz = array([dict(ques=str,p1=str,p2=str,rep=int)]*n)
Trep = array([dict(id=str,ques=str,nump=int)]*n)
numQ=0      # variable qui contient le numéro de la question en cours
App = QApplication([])
fen = loadUi ("Interface_Reponse.ui")
fen.show()
fen.btnTest.clicked.connect(test)
fen.vld.clicked.connect(validation)
App.exec_()