from PyQt5.QtWidgets import *
from PyQt5.uic import *
def afficher():
    w.tw.setrowcount(0)
    f=open("bresilien.dat","rb")
    i=0
    if not w.cc.ischecked():
        ff=False
        while not ff:
            try:
                v=load(f)
                w.tw.insertRow(i)
                w.tw.setIem(i,0,QtableWidgetItem(str(v["n"])))
                w.tw.setIem(i,0,QtableWidgetItem(str(v["b"])))
                w.tw.setIem(i,0,QtableWidgetItem(str(v["rep"])))
                i=i+1
            except:
                ff=True
    else:
        b=int(w.cb.currentText())
        ff=False
        while not ff:
            try:
                v=load(f)
                if v["b"]=b
                w.tw.insertRow(i)
                w.tw.setIem(i,0,QtableWidgetItem(str(v["n"])))
                w.tw.setIem(i,0,QtableWidgetItem(str(v["b"])))
                w.tw.setIem(i,0,QtableWidgetItem(str(v["rep"])))
                i=i+1
            except:
                ff=True
    f.close()

#----------------------------------------------Exploitation de l'interface graphique-------------
app=QApplication([])
w=loadUi("Inter_consult.ui")
w.show()
w.bt1.clicked.connect(afficher)
w.bt2.clicked.connect(annuler)
app.exec_()