from PyQt5.QtWidgets import *
from PyQt5.uic import *
from pickle import*


def conv10b(n,b):
    chv=""
    ok=False
    
    while not ok:
        
        r=n%b
        if r<10:
            chv=str(r)+chv
        else:
            chv=chr(r+55)+chv
        n=n//b
        ok=n==0
    
    return chv
def indentique(ch):
    test=True
    s=ch[0]
    i=1
    while(i<len(ch) and test ):
        if ch[i]==ch[0]:
            i=i+1
        else: 
            test=False
    return test
def existant(ch):
    try:
        f=open("bresilien.dat","rb")
        ff=False
        ex=False
        while not ff and not ex:
            try:
                e=load(f)
                if e["n"]==int(ch):
                    ex=True
            except:
                ff=True
        return ex
    except:
        return False
def ajouter():
    ch=w.le.text()
    if(ch==""):
        QMessageBox.critical(w,"Erreur 1","veuille saisir n!")
    elif not(ch.isdecimal() and int(ch)>1 ):
         QMessageBox.critical(w,"Erreur 2","Nombre invalide!")
    elif(existant(ch)):
         QMessageBox.critical(w,"Erreur 4","Nombre déja existant!")
    else:
        e=dict(n=int,b=int,rep=int)
        nb=2
        test=False
        
        while nb<=int(ch)-2 and not test and nb<=16:
            print("*")
            s=conv10b(int(ch),nb)
            print(s)
            if indentique(s)==True:
                test=True
            else:
                nb=nb+1
        if(test==True):
            e["n"]=int(ch)
            e["b"]=nb
            e["rep"]=s
            f=open("bresilien.dat","ab")
            dump(e,f)
            f.close()
            chh="("+ch+")10="+"("+str(s)+")"+str(nb)
            w.lb.setText(chh)
        else:
            QMessageBox.critical(w,"Erreur 3","le nombre n'est pas bresilien!")
        
def Annuler():
    w.le.clear()
    w.lb.clear()
        
        
    
#----Exploitation de l'interface graphique----
app=QApplication([])
w=loadUi("Inter_ajout.ui")
w.show()
w.bt1.clicked.connect(ajouter)
w.bt2.clicked.connect(Annuler)
app.exec_()