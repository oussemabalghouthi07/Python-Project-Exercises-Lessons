from PyQt5.QtWidgets import *
from PyQt5.uic import *
from pickle import dump,load
from math import *
def valide(x):
    p=x.find(".")
    if x.find(".")!=1 or x[0]!="0":
        return False
    elif(x[p+1:len(x)].isdecimal()==False):
        return False
    else:
        return True
def c(x):
    return (x-6)*(x-6)+sin(x-6)+2
def calculer():
    eps=w1.le.text()
    if(valide(eps)==False):
        QMessageBox.critical(w1,"Erreur","epsilon invalide!!")
    else:
        e=dict(it=int,x=float,c=float)
        f1=open("calculs.dat","wb")
        i=1
        e["it"]=1
        e["x"]=2
        e["c"]=c(2)
        dump(e,f1)
        ok=False
        while not(ok):
            sp=e["c"]
            e["it"]=i+1
            e["x"]=float(e["x"])+float(eps)
            e["c"]=c(float(e["x"]))
            i=i+1
            if e["c"]<sp:
                dump(e,f1)
            ok=((float(e["c"])>sp)or float(e["x"])>10)
        f1.close()
        res=eps+"#"+str(e["it"])+"#"+ str(e["x"])+"#"+str(e["c"])
        f2=open("Resultat.txt","a")
        f2.write(res+"\n")
        f2.close()
        
        
        f1=open("calculs.dat","rb")
        ff=False
        i=0
        w1.tw.setRowCount(0)
        while not ff:
            try:
                e=load(f1)
                w1.tw.insertRow(i)
                w1.tw.setItem(i,0,QTableWidgetItem(str(e["it"])))
                w1.tw.setItem(i,1,QTableWidgetItem(str(e["x"])))
                w1.tw.setItem(i,2,QTableWidgetItem(str(e["c"])))
                i=i+1
            except:
                ff=True
        f1.close()
        
def annuler1():
    w1.le.clear()
def annuler2():
    w2.min.clear()
    w2.max.clear()
    w2.lw.clear()
def afficher():
    w2.lw.clear()
    min=w2.min.text()
    max=w2.max.text()
    if(valide(max)==False or valide(min)==False or float(min)<0 or float(max)>1):
        QMessageBox.critical(w2,"Erreur","Filtre invalide!")
    else:
        if(w2.ck.isChecked()==False):
            f2=open("Resultat.txt","r")
            ph=f2.read()
            w2.lw.addItem(ph)
            f2.close()
        else:

            ff=False
            f2=open("Resultat.txt","r")
            while not ff :
                try:
                    ch=f2.readline()
                    ch=ch[0:len(ch)-1]
                    ep=float(ch[0:(ch.find("#"))])
                    if float(min)<ep<float(max):
                        w2.lw.addItem(ch)
                except:
                    ff=True
            f2.close()

#----------------------------------------------Exploitation de l'interface graphique-------------
app=QApplication([])
w1=loadUi("inter_optimisation.ui")
w1.show()
w2=loadUi("inter_aff.ui")
w2.show()
w1.b1.clicked.connect(calculer)
w1.b2.clicked.connect(annuler1)
w2.b1.clicked.connect(afficher)
w2.b2.clicked.connect(annuler2)
app.exec_()