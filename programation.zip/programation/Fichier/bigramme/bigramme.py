def remplire(t,f1):
    global n
    ch=f1.read()
    i=0
    n=0
    while i<len(ch)-1:
        
        if ch[i]!="\n" and ch[i]!="*":
            k=""
            if ch[i]==ch[i+1]:
                k=ch[i]+ch[i+1]
                if existe(k,t,n)!=0:
                    t[existe(k,t,n)]["Nbocc"]=t[existe(k,t,n)]["Nbocc"]+1
                    print(t[existe(k,t,n)]["Nbocc"])
                else:
                    
                    t[n]=dict()
                    t[n]["big"]=k
                    t[n]["Nbocc"]=1
                    print(t[n])
                    n=n+1      
        i=i+1
    print(t)
def existe(ch,t,n):
    i=0
    nb=0
    while i<n and nb==0:
        if ch==t[i]["big"]:
            nb=i
        else:
            i=i+1
    print(nb)
    return nb
def trier(t,f2,n):
    for i in range(1,n):
        if t[i]["Nbocc"]>t[i-1]["Nbocc"] or (t[i]["Nbocc"]==t[i-1]["Nbocc"] and t[i]["Nbocc"]>t[i-1]["Nbocc"]):
            v=t[i]
            j=i-1
            while((j>=0) and((t[j]["Nbocc"]<v["Nbocc"])or (t[j]["Nbocc"])==v["Nbocc"] and t[j]["big"]<v["big"])):
                t[j+1]=t[j]
                j=j-1
            t[j+1]=v
    for i in range(n):
        f2.write(t[i]["big"]+":de nombre d'occurence="+str(t[i]["Nbocc"])+"\n")
def afficher(t,f2,n):
    for i in range(n):
        ch=f2.readline()
        print(ch)
    print(t)
        





from numpy import array
t=dict(big=str,Nbocc=int)
f1=open("texte.txt","r")
remplire(t,f1)
f1.close()
f2=open("resultat","w")
trier(t,f2,n)
f2.close()
f2=open("resultat","r")
afficher(t,f2,n)
f2.close()
