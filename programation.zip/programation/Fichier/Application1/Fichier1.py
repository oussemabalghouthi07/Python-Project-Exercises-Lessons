def saisir():
    global n
    ok=False
    while not ok:
        n=int(input("donne rtaille de fichier"))
        ok=1<n<=20
def remplir(f1,n):
    for i in range(n):
        ok=False
        while not(ok):
            ch=input("donner une chaine:")
            ok=len(ch)!=0
        f1.write(ch+"\n")
def transferer(f2,f1,n):
    for i in range(n):
        ch=f1.readline()
        ch=ch[0:len(ch)-1]
        if verif(ch):
            f2.write(ch+"\n")
def verif(ch):
    i=0
    test=True
    while (i<len(ch)) and test:
        test=("A"<=ch[i]<="Z") or ("a"<=ch[i]<="z")
        i=i+1
    return test
def afficher(f2):
    ch=f2.read()
    print(ch)   
saisir()
f1=open("chaine.txt","w")
remplir(f1,n)
f1.close()
f1=open("chaine.txt","r")
f2=open("alphabets.txt","w")
transferer(f2,f1,n)
f1.close()
f2.close()
f2=open("alphabets.txt","r")
afficher(f2)
f2.close()