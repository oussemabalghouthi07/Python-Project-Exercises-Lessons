def saisir():
    global n
    n=int(input("donner n:"))
    while not 1<=n<=50:
        n=int(input("donner n:"))
def stocker(f1,n):
    for i in range(n):
        ch=input("donner le mot pour le crypter:")
        while not verif :
            ch=input("donner le mot pour le crypter:")
        f1.write(ch+"\n")
def verif (ch):
    test=True
    while i<len(ch) and test:
        if ("A"<=ch[i]<="Z") or ("A"<=ch[i]<="Z") or (ch[i]==" "):
            i=i+1
        if ch[i]==" ":
            if ch[i+1]==" ":
                test=False
    return test
            
def crypter(f2,f1,n):
    j=0
    p=0
    for i in range(n):
        cr=""
        ch=f1.readline()
        ch=ch+" "
        for c in range(len(ch)):
            if ch[c]==" ":
                mt=ch[j:c]
                p=p+1
                j=c
                for v in range(len(mt)):
                    if mt[v]!=" ":
                        cr=cr+chr(ord(mt[v])+p)
                cr=cr+" "
        f2.write(cr[0:len(cr)-2]+"\n")
def afficher(f2):
    ch=f2.read()
    print(ch) 
                
                
saisir()
f1=open("phrases.txt","w")
stocker(f1,n)
f1.close()
f1=open("phrases.txt","r")
f2=open("ph_crypt.txt","w")
crypter(f2,f1,n)
f1.close()
f2.close()
f2=open("ph_crypt.txt","r")
afficher(f2)
f2.close()
