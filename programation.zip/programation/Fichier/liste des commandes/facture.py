def saisir():
    global n
    n=int(input("donner n:"))
    while not 1<=n<=30:
        n=int(input("donner n:"))
def remplir(f1,n):
    for i in range(n):
        article["Num_fact"]=(input("donner le numero du facture n°"+str(i)+":"))
        while not article["Num_fact"]==str(i) :
            article["Num_fact"]=int(input("donner le numero du facture n°"+str(i)+":"))
        article["nom"]=(input("donner le nom d'article n°"+str(i)+":"))
        while not len(article["nom"])<=30:
            article["nom"]=(input("donner le nom d'article n°"+str(i)+":"))
        article["qte"]=int(input("donner la contité du commande :"))
        article["prix"]=float(input("donner le prix du facture "))
        article["etat"]=(input("donner l'etat paye ou non paye:"))
        while not article["etat"]in["paye","non paye"]:
            article["etat"]=(input("donner l'etat paye ou non paye:"))
    dump(article,f1)
def transfer(f1,f2,n):
    global v
    v=0
    for i in range(n):
        if article["etat"]=="non paye":
            enrg["num_fact"]=article["num_fact"]
            enrg["nom"]=article["nom"]
            enrg["montant"]=(article["qte"])*(article["prix"])
            v=v+1
        dump(enrg,f2)
def afficher(f2,v):
    for i in range(v):
        print("le numero du facture:",(enrg["num_fact"]))
        print("le nom:",enrg["nom"])
        print("le nmontant:",enrg["montant"])
        
from pickle import*  
saisir()
article=dict(num_fact=str,nom=str,qte=int,prix=float,etat=str)
enrg=dict(num_fact=str,nom=str,montant=float)
f1=open("commande.txt","wb")
remplir(f1,n)
f1.close()
f1=open("commande.txt","rb")
f2=open("facture.txt","wb")
transfer(f1,f2,n)
f1.close()
f2.close()
f2=open("facture.txt","rb")
afficher(f2,v)
f2.close()