from pickle import*
def saisir():
    global n
    n=int(input("donner n:"))
    while not 5<=n<=100:
        n=int(input("donner n:"))
def remplir(f1,n):
    for i in range(n):
        x=int(input("donner x("+str(i)+"):"))
        while not x>1:
            x=int(input("donner x("+str(i)+"):"))
        dump(x,f1)
def former(f1,f2,n):
    global v
    v=0
    for i in range(n):
        x=load(f1)
        if premier(x):
            dump(x,f2)
            v=v+1
def premier(x):
    test=True
    i=2
    while i<(x//2) and test :
        if (x%i)!=0:
            i=i+1
        else:
            test=False
    return test
def afficher2(f2,v):
    for i in range(v):
        p=load(f2)
        print("fich2="+str(p))
def afficher1(f1,n):
    for i in range(n):
        x=load(f1)
        print("fich1="+str(x))

saisir()
f1=open("entier.txt","wb")
remplir(f1,n)
f1.close()
f1=open("entier.txt","rb")
f2=open("premier.txt","wb")
former(f1,f2,n)
f1.close()
f2.close()
f2=open("premier.txt","rb")
afficher2(f2,v)
f2.close()
f1=open("entier.txt","rb")
afficher1(f1,n)
f1.close()
