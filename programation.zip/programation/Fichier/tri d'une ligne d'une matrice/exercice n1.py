def remplir(f1):
    global n
    n=0
    rep="O"
    while rep.upper()=="O":
        ch=input("donner une chaine numerique:")
        while not ch.isdecimal:
            ch=input("donner une chaine numerique:")
        f1.write(ch+"\n")
        n=n+1
        rep=input("tu ne veut pas continue?")
        while not (rep.upper()=="O" or rep.upper()=="N" ):
            rep=input("tu ne veut pas continue?")
       
       

def transfer(f1,m,n):
    for i in range (n):
        ch=f1.readline()
        ch=ch[0:len(ch)-1]
        print(ch)
        r=""
        v=""
        if n<len(ch):
                l=ch[0:n]
                print(l)
                for j in range(n):
                    m[i,j]=ch[j]
        else:
            v=n-len(ch)
            for c in range(v):
                r=str(randint(0,9))+r
            t=r+ch
            for b in range(n):
                m[i,b]=t[b]
    print(m)
def trier(m,n):
    for i in range(0,n):
        for j in range(1,n):
            if m[i,j]<m[i,j-1]:
                v=m[i,j]
                l=j-1
                while not ((l<0)or (m[l,j]<v)):
                    m[i,l+1]=m[i,l]
                    l=l-1
                m[i,l+1]=v
    print()
    print(m)
def reconstruir(f1,m,n):
    for j in range(n):
        ch=""
        for i in range(n):
            ch=ch+m[i,j]
        print(ch)
        f1.write(ch)
        
from pickle import*
from  numpy import array
from random import*
f1=open ("source.txt","w")
remplir(f1)
f1.close()
m= array([[int]*n]*n)
f1=open ("source.txt","r")
transfer(f1,m,n)
f1.close()
trier (m,n)
f1=open("source.txt","w")
reconstruir(f1,m,n)
f1.close()


