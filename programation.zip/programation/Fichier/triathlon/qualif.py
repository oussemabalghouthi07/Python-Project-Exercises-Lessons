from numpy import*
def remplir(f1):
    global n
    rep="N"
    n=0
    while not(rep=="O" or rep=="o"):
        e["nom"]=input("donner le nom du participation:")
        while not(len(e["nom"])>0 and verif(e["nom"])):
            e["nom"]=input("donner le nom du participation:")
        e["natation"]=float(input("donner le durée de natation:"))
        while not (e["natation"]>0):
            e["natation"]=float(input("donner le durée de natation:"))
        e["cyclisme"]=float(input("donner le durée de cyclisme:"))
        while not(e["cyclisme"]>0):
            e["cyclisme"]=float(input("donner le durée de cyclisme:"))
        e["course_p"]=float(input("donner le durée de course a pied:"))
        while not (e["course_p"]>0):
            e["course_p"]=float(input("donner le durée de course a pied:"))
        n=n+1
        print(n)
        rep=input("vous-voulez arreter?")
        while not(rep.upper()=="O" or rep.upper()=="N"):
            rep=input("vous-voulez arreter?")
        dump(e,f1)
def verif(ch):
    test=True
    i=0
    while (i<len(ch) and test):
        if "a"<=ch[i]<="z" or "A"<=ch[i]<="Z" or ch[i]==" ":
            i=i+1
        else:
            test=False
    return test
def transfer(f1,f2,n):
    for l in range(n):
        e=load(f1)
        ol["nom"]=e["nom"]
        ol["somme"]=e["natation"]+e["cyclisme"]+e["course_p"]
        print(ol["nom"],ol["somme"])
        dump(ol,f2)
    
def trier(f2,n):
    t=array([float]*n)
    t2=array([str]*n)
    for l in range(n):
        ol=load(f2)
        print(ol)
        t[l]=ol["somme"]
        t2[l]=ol["nom"]
    for i in range(1,n):
        if t[i]<t[i-1]:
            v=t[i]
            temp=t2[i]
            j=i-1
            while not ((j<0)or (t[j]<v)):
                t[j+1]=t[j]
                t2[j+1]=t2[j]
                j=j-1
            t[j+1]=v
            t2[j+1]=temp
    
    f2=open("olymp.dat","wb")
    for j in range(n):
        ol["nom"]=t2[j]
        ol["somme"]=t[j]
        
        dump(ol,f2)
        print(ol)
    f2.close()
def afficher(f2,n):
    for i in range(n):
        ol=load(f2)
        print(str(i+1)+"-"+ol["nom"])
        


from pickle import*  
e=dict(nom=str,natation=float,cyclisme=float,course_p=float)
ol=dict(nom=str,somme=float)
f1=open("qualification.dat","wb")
remplir(f1)
f1.close()
f1=open("qualification.dat","rb")
f2=open("olymp.dat","wb")
transfer(f1,f2,n)
f1.close()
f2=open("olymp.dat","rb")
trier(f2,n)
f2.close()
f2=open("olymp.dat","rb")
afficher(f2,n)
f2.close()