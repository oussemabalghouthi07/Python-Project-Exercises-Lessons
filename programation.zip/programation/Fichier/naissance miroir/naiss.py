from pickle import*
def saisir():
    global n
    n=int(input("donner n:"))
    while not 3<=n<=20:
        n=int(input("donner n:"))
def remplir(f1,n):
    for i in range(n):
        e["nom"]=input("donner votre nom et prenom svp:")
        while not (len(e["nom"])!=0 ):
            e["nom"]=input("donner votre nom et prenom svp:")
        e["heure"]=input("donner l'heure svp:")
        while not (e["heure"].find(":")==2 and len(e["heure"])==5):
            e["heure"]=input("donner l'heure svp:")
        dump(e,f1)
def former(f1,f2,n):
    ni=0
    nt=0
    nd=0
    for i in range(n):
        e=load(f1)
        print(e)
        h=e["heure"]
        print(h)
        if h[0:e["heure"].find(":")]==h[e["heure"].find(":")+1:len(h)]:
            f2.write((e["nom"])+":heure miroire doublée"+"\n")
            nd=nd+1
            print(nd)
        if ((h[0]==h[1])and(h[1]==h[3]))or((h[1]==h[3])and(h[3]==h[4])):
            f2.write(e["nom"]+":heure miroire triplée"+"\n")
            nt=nt+1
            print(nt)
        if (h[0]==h[4]) and (h[1]==h[3]):
            f2.write(e["nom"]+":heure miroire inversée"+"\n")
            ni=ni+1
            print(ni)
    
    print("le nombre des nouveau-nés ayant l'heure de naissance miroire doublée est"+str(nd))
    print("le nombre des nouveau-nés ayant l'heure de naissance miroire triplée est"+str(nt))
    print("le nombre des nouveau-nés ayant l'heure de naissance miroire inversée est"+str(ni))  


saisir()
e=dict(nom=str,heure=str)
f1=open("naiss.dat","wb")
remplir(f1,n)
f1.close()
f1=open("naiss.dat","rb")
f2=open("miroir.txt","w")
former(f1,f2,n)
f1.close()
f2.close()