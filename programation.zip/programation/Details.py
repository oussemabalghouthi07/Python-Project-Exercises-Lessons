def pgcd(a,b):
    if b==0:
        return a
    else:
        return pgcd(b,a%b)
def ppcm(a,b,p):
    if(p%b)==0:
        return p
    else:
        return ppcm(a,b,p+a)
def decomp(x):
    i=2
    ch=""
    while not(x==1):
        if x%i==0:
            ch=ch+str(i)+"*"
            x=x//i
        else:
            i=i+1
    return ch
def premiers(x):
    test=True
    i=2
    while i<(x//2) and test:
        if x%i!=0:
            i=i+1
        else:
            test=False
    return test
def convertion(x,b):
    s=0
    p=1
    for i in range(len(x)-1,-1,-1):
        if("A"<=x[i]<="F"):
            s=s+(ord(x[i])-55)*p
        else:
            s=s+(ord(x[i])-48)*p
        p=p*b
    return s
def meth_rect(a,b,N):
    h=(b-a)/N
    x=a       x=a+h      x=a+(h/2)
    s=0
    for i in range(1,N):
        s=s+h*f(x)
        x=x+h
    return s
def meth_trap(a,b,N):
    h=(a-b)/N
    x=a
    s=0
    for i in range(1,N):
        s=s+h*(f(x)+(x+h))/2
        x=x+h
    return s
def tri_selection(t,n):
    for i in range(1,n):
        if(t[i]<t[i-1]):
            aux=t[i]
            j=i-1
            while not j<0 or t[j]<v:
                t[j+1]=t[j]
                j=j-1
def tri_bulle(t,n):
    test=True
    while test:
        test=False
        for i in range(n-1):
            if t[i]<t[i+1]:
                test=True
                aux=t[i]
                t[i]=t[i+1]
                t[i+1]=aux
def convertion10_b(x,b):
    ch=""
    while not x==0:
        r=x%b
        if(r<10):
            ch=chr(r)+ch
        else:
            ch=chr(r+55)+ch
        x=x//b
    return ch